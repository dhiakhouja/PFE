import flask
import pandas as pd
from joblib import dump, load


with open(f'./SelectedRFModel.joblib', 'rb') as f:
    model = load(f)


app = flask.Flask(__name__, template_folder='templates')


@app.route('/predict_ml', methods=['GET', 'POST'])
def main():
    # if flask.request.method == 'GET':
    #     return (flask.render_template('index.html'))

    if flask.request.method == 'POST':
        gender= flask.request.form['gender']
        age = flask.request.form['age']
        educ = flask.request.form['educ']
        ses = flask.request.form['ses']
        mmse = flask.request.form['mmse']
        etiv = flask.request.form['etiv']
        nwbv = flask.request.form['nwbv']
        asf = flask.request.form['asf']
        print(gender, age, educ, ses, mmse, etiv,nwbv, asf)
        if gender == 'men':
            gender = 0
        else:
             gender = 1
        input_variables = pd.DataFrame([[gender, age , educ, ses, mmse, etiv, nwbv, asf]],
                                       columns=['M/F','Age' , 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF'],
                                       dtype='float',
                                       index=['input'])

        predictions = model.predict(input_variables)[0]
        result = 'Malade'
        if predictions ==0:
            result = ' Non malade'
        print(predictions)

        return flask.render_template('result.html', original_input={'gender':gender, 'age': age, 'educ': educ, 'ses': ses, 'mmse': mmse, 'etiv': etiv, 'nwbv': nwbv, 'asf': asf},
                                     result=result)


if __name__ == '__main__':
    app.run(debug=True)