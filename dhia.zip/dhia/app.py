from __future__ import division, print_function

import flask
import pandas as pd
from joblib import dump, load
# coding=utf-8
import sys
import os
import glob
import re
import numpy as np

# Keras
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
from tensorflow.keras.models import load_model
from tensorflow.keras.models import model_from_json
import json
from keras.preprocessing import image

# Flask utils
from flask import Flask, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer


def load_cnn_model(architecture_path, params_path):

    json_file = open(architecture_path, 'r')
    loaded_model_json = json_file.read()
    model = model_from_json(loaded_model_json)
    # load weights into new model
    model.load_weights(params_path)
    print("Loaded model from disk")
    return model

model_dl = load_cnn_model('./models/model.json', './models/model.h5')

with open(f'./models/SelectedRFModel.joblib', 'rb') as f:
    model_ml = load(f)



app = flask.Flask(__name__, template_folder='templates')

######################## ML ########################
@app.route('/predict_ml', methods=['GET', 'POST'])
def predict_ml():
    # if flask.request.method == 'GET':
    #     return (flask.render_template('index.html'))

    if flask.request.method == 'POST':
        gender= flask.request.form['gender']
        age = flask.request.form['age']
        educ = flask.request.form['educ']
        ses = flask.request.form['ses']
        mmse = flask.request.form['mmse']
        etiv = flask.request.form['etiv']
        nwbv = flask.request.form['nwbv']
        asf = flask.request.form['asf']
        print(gender, age, educ, ses, mmse, etiv,nwbv, asf)
        if gender == 'men':
            gender = 0
        else:
             gender = 1
        input_variables = pd.DataFrame([[gender, age , educ, ses, mmse, etiv, nwbv, asf]],
                                       columns=['M/F','Age' , 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF'],
                                       dtype='float',
                                       index=['input'])

        predictions = model_ml.predict(input_variables)[0]
        result = 'Malade'
        if predictions ==0:
            result = ' Non malade'
        print(predictions)

        return flask.render_template('result.html', original_input={'gender':gender, 'age': age, 'educ': educ, 'ses': ses, 'mmse': mmse, 'etiv': etiv, 'nwbv': nwbv, 'asf': asf},
                                     result=result)


######################## DL ########################

def model_predict(img_path, model):
    img = image.load_img(img_path, target_size=(224, 224))

    # Preprocessing the image
    x = image.img_to_array(img)
    # x = np.true_divide(x, 255)
    x = np.expand_dims(x, axis=0)

    # Be careful how your trained model deals with the input
    # otherwise, it won't make correct prediction!
    x = preprocess_input(x, mode='caffe')

    preds = model.predict(x)
    return preds


@app.route('/predict_dl', methods=['GET', 'POST'])
def predict_dl():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['file']
        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        # Make prediction
        preds = model_predict(file_path, model_dl)
        print(preds)
        # Process your result for human
        pred_class = preds.argmax(axis=-1)[0]            # Simple argmax
        classes_names = {
            0: ' None demanted',
            1: 'Mild demanted',
            2:' Very mild demented',
            3: 'Other'
        }
        # pred_class = decode_predictions(preds, top=1)   # ImageNet Decode
        # result = str(pred_class[0][0][1])               # Convert to string
        
        print(pred_class, classes_names[pred_class])
        return flask.render_template('result.html',  result=classes_names[pred_class])
    return None


if __name__ == '__main__':
    app.run(debug=True)