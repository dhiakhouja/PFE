from __future__ import division, print_function
# coding=utf-8
import sys
import os
import glob
import re
import numpy as np

# Keras
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
from tensorflow.keras.models import load_model
from tensorflow.keras.models import model_from_json
import json
from keras.preprocessing import image

# Flask utils
from flask import Flask, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer

import flask

# Define a flask app
app = flask.Flask(__name__, template_folder='templates')


def load_cnn_model(architecture_path, params_path):

    json_file = open(architecture_path, 'r')
    loaded_model_json = json_file.read()
    model = model_from_json(loaded_model_json)
    # load weights into new model
    model.load_weights(params_path)
    print("Loaded model from disk")

    # with open(architecture_path,'r') as f:
    #     model_json = json.load(f)
    # print(model_json)
    # model_json = str(model_json)
    # model_json = model_json.replace("\'", "\"")
    # model_json = json.loads(model_json)
    # print(model_json)

    # model = model_from_json(model_json)
    # model.load_weights(params_path)
    return model

model = load_cnn_model('model.json', './model.h5')

# Model saved with Keras model.save()
#MODEL_PATH = './model.h5'
# Load your trained model
#model = load_model(MODEL_PATH)
#model._make_predict_function()          # Necessary
# print('Model loaded. Start serving...')

# You can also use pretrained model from Keras
# Check https://keras.io/applications/
#from keras.applications.resnet50 import ResNet50
#model = ResNet50(weights='imagenet')
#model.save('')
print('Model loaded. Check http://127.0.0.1:5000/')


def model_predict(img_path, model):
    img = image.load_img(img_path, target_size=(224, 224))

    # Preprocessing the image
    x = image.img_to_array(img)
    # x = np.true_divide(x, 255)
    x = np.expand_dims(x, axis=0)

    # Be careful how your trained model deals with the input
    # otherwise, it won't make correct prediction!
    x = preprocess_input(x, mode='caffe')

    preds = model.predict(x)
    return preds


@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')


@app.route('/predict_dl', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['file']
        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        # Make prediction
        preds = model_predict(file_path, model)
        print(preds)
        # Process your result for human
        pred_class = preds.argmax(axis=-1)[0]            # Simple argmax
        classes_names = {
            0: ' None demanted',
            1: 'Mild demanted',
            2:' Very mild demented',
            3: 'Other'
        }
        # pred_class = decode_predictions(preds, top=1)   # ImageNet Decode
        # result = str(pred_class[0][0][1])               # Convert to string
        
        print(pred_class, classes_names[pred_class])
        return flask.render_template('result.html',  classes_names=classes_names[pred_class])
    return None


if __name__ == '__main__':
    app.run(debug=True)
    